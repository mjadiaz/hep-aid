### Sources

- [ Introduction to SARAH and related tools](http://cds.cern.ch/record/2054763/files/arXiv%3A1509.07061.pdf?version=1)
- [ A tool box for implementing supersymmetric models](https://arxiv.org/pdf/1109.5147.pdf)
- [ SPheno 2004](https://arxiv.org/pdf/hep-ph/0301101.pdf)
- [SPheno 3.1 2011 extension](https://arxiv.org/pdf/1104.1573.pdf)