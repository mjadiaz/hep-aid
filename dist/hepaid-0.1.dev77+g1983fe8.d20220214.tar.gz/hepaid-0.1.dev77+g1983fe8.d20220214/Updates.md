
#### Wed  5 Jan 17:37:17 2022

- Patterns ready


**ToDo:**
- Now we need to populate the blocks with the new patterns

